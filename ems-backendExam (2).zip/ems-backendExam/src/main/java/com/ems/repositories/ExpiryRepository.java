package com.ems.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ems.bean.CardExpiry;

public interface ExpiryRepository extends CrudRepository<CardExpiry, String> {

}
