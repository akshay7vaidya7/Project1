package com.ems.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ems.bean.BillingDetails;

public interface BillingRepository extends CrudRepository<BillingDetails, String> {

}
