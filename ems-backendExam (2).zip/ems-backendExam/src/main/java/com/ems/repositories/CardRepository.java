package com.ems.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ems.bean.Card;

public interface CardRepository extends CrudRepository<Card, String> {

}
