package com.ems.repositories;

import org.springframework.data.repository.CrudRepository;


import com.ems.bean.PaymentMethod;



public interface PaymentRepository extends CrudRepository<PaymentMethod, String> {

	

}
