package com.ems.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ems.bean.ReturnLink;

public interface ReturnRepository extends CrudRepository<ReturnLink, String> {

}
