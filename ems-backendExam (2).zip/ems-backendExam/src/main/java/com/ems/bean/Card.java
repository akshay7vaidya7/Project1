package com.ems.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Card {
	
	
	@Id
	private String holderName;
	private String cardType;
	private String cardBin;
	private String lastDigits;
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardBin() {
		return cardBin;
	}
	public void setCardBin(String cardBin) {
		this.cardBin = cardBin;
	}
	public String getLastDigits() {
		return lastDigits;
	}
	public void setLastDigits(String lastDigits) {
		this.lastDigits = lastDigits;
	}
	@Override
	public String toString() {
		return "Card [holderName=" + holderName + ", cardType=" + cardType + ", cardBin=" + cardBin + ", lastDigits="
				+ lastDigits + "]";
	}
	
	

}
