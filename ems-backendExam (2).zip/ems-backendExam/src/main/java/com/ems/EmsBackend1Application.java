package com.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsBackend1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmsBackend1Application.class, args);
	}

}
